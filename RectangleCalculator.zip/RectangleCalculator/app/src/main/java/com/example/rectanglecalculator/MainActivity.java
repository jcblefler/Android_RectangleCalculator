package com.example.rectanglecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private Button mButton;
    private EditText width;
    private EditText height;
    private TextView area;
    private TextView parameter;

    private static DecimalFormat df2 = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mButton = (Button)findViewById(R.id.calcButton);

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculations(v);
            }
        });
    }




    public void calculations(View view){
        width = (EditText)findViewById(R.id.widthText);
        double w = Double.parseDouble(width.getText().toString());

        height = (EditText)findViewById(R.id.heightText);
        double h = Double.parseDouble(height.getText().toString());

        area = (TextView)findViewById(R.id.areaText);
        area.setText(df2.format((w * h)));

        parameter = (TextView)findViewById(R.id.parameterText);
        double p = ((2 * w) + (2 * h));
        parameter.setText(df2.format(p));
    }
}
